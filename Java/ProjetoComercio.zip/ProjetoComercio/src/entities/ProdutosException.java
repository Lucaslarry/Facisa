package entities;

public class ProdutosException extends Exception {

    public ProdutosException(String msg) {
        super(msg);
    }

}
